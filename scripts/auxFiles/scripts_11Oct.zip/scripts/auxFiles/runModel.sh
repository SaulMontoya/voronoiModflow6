cd ../model
../exe/mf6
